extends Node3D
## Прохожие: гуляют по тротуарам вокруг кварталов, машут ногами и руками,
## останавливаются перед игроком. Если сбить машиной — падают и через
## несколько секунд «уходят» в другой квартал. Далёкие не рисуются.

const CityBuilder := preload("res://scripts/city_builder.gd")
const BodyMesh := preload("res://scripts/body_mesh.gd")
const Poses := preload("res://scripts/poses.gd")
const Hats := preload("res://scripts/hats.gd")

const COUNT := 44
var count := COUNT   # сколько создать (на слабом устройстве меньше)
const WALK := 34.0          # середина тротуара от центра квартала
const SPEED := 1.4
const SHIRTS := [
    Color(0.80, 0.20, 0.20), Color(0.20, 0.50, 0.80), Color(0.90, 0.70, 0.20),
    Color(0.30, 0.60, 0.30), Color(0.55, 0.30, 0.60), Color(0.92, 0.92, 0.92),
    Color(0.15, 0.15, 0.17), Color(0.85, 0.45, 0.20),
]
const PANTS := [Color(0.18, 0.22, 0.32), Color(0.12, 0.12, 0.13), Color(0.40, 0.35, 0.30)]

## 3D-прохожие: та же модель, что у игрока (мужчина) и женская. Одежда — ткани по маске.
const CHAR_DIR := "res://models/character/"
const MALE_TOPS := [["cloth_bolonya_green", ""], ["cloth_wool_gray", ""], ["cloth_gabardine", ""],
        ["cloth_quilted_navy", ""], ["cloth_check_blue", "short"], ["cloth_nylon_blue", ""], ["cloth_corduroy", ""],
        ["cloth_cotton_white", "short"], ["cloth_leather_black", ""], ["cloth_leather_brown", ""], ["cloth_red_cotton", "short"]]
const MALE_PANTS := ["cloth_wool_black", "cloth_jersey_gray", "cloth_acidwash", "cloth_trousers_brown", "cloth_denim_blue", "cloth_gabardine"]
const MALE_SHOES := ["cloth_leather_black", "cloth_leather_brown", "cloth_canvas_white", "cloth_rubber_black"]
const FEMALE_TOPS := [["cloth_chintz", "dress"], ["cloth_chintz", "dress,short"], ["cloth_cardigan", ""], ["cloth_bolonya_green", ""],
        ["cloth_gabardine", ""], ["cloth_cotton_white", "short"], ["cloth_check_blue", "short"], ["cloth_red_cotton", "short"]]
const FEMALE_PANTS := ["cloth_wool_black", "cloth_acidwash", "cloth_trousers_brown", "cloth_denim_blue"]
const FEMALE_SHOES := ["cloth_leather_black", "cloth_canvas_white", "cloth_rubber_black", "cloth_leather_brown"]
const HAIR_COLORS := [Color(0.10, 0.07, 0.05), Color(0.30, 0.20, 0.12), Color(0.55, 0.42, 0.25), Color(0.80, 0.68, 0.42),
        Color(0.55, 0.25, 0.10), Color(0.60, 0.60, 0.60), Color(0.05, 0.05, 0.05)]
const SKIN_TINTS := [Vector3(1.0, 1.0, 1.0), Vector3(1.08, 1.12, 1.15), Vector3(0.85, 0.78, 0.70), Vector3(0.70, 0.60, 0.50)]

var _scenes := {}        # "male"/"female" -> PackedScene
var _tex := {}
var _shader: Shader = null

signal knocked(pos: Vector3)   # сбили машиной (для розыска)

var player: Node3D = null    # пешеход останавливается перед ним
var cars: Array = []         # машины игрока — ими можно сбить
var focus := Vector3.ZERO

var _peds: Array = []
var _rng := RandomNumberGenerator.new()
var _skin: StandardMaterial3D
## [рост, плечи, живот, бёдра] — обычные чаще
const BUILDS := [[1, 1, 1, 1], [1, 1, 1, 1], [1, 1, 1, 1], [1.01, 0.92, 0.88, 0.9], [1.02, 1.1, 0.97, 1.05],
        [0.99, 1.06, 1.2, 1.08], [1.05, 1.02, 1, 1.02], [0.95, 1, 1.03, 1]]
var _body_meshes := {}
var _leg_meshes := {}


func setup() -> void:
    _rng.randomize()
    if ResourceLoader.exists("res://shaders/character.gdshader"):
        _shader = load("res://shaders/character.gdshader")
        for k: String in ["male", "female"]:
            var path: String = preload("res://scripts/outfits.gd").male_model() if k == "male" else preload("res://scripts/outfits.gd").female_model()
            if ResourceLoader.exists(path):
                var sc = load(path)
                if sc is PackedScene:
                    _scenes[k] = sc
    _skin = StandardMaterial3D.new()
    _skin.albedo_color = Color(0.87, 0.68, 0.55)
    for i in count:
        var p := _make_ped()
        _place_random(p)
        _peds.append(p)


var _blockers: Array[Vector3] = []   # стоящие люди (НПС) рядом — их обходят
var _blk_t := 0.0


func _process(delta: float) -> void:
    _blk_t -= delta
    if _blk_t <= 0.0:
        _blk_t = 0.5
        _blockers.clear()
        for n: Node in get_tree().get_nodes_in_group("npc_block"):
            var n3 := n as Node3D
            if n3 and n3.is_visible_in_tree() and n3.global_position.distance_to(focus) < 80.0:
                _blockers.append(n3.global_position)
    for p: Dictionary in _peds:
        var root: Node3D = p["root"]
        var pos: Vector3 = p["pos"]

        if p["down"]:
            p["timer"] = float(p["timer"]) - delta
            if float(p["timer"]) <= 0.0:
                root.rotation = Vector3.ZERO
                p["down"] = false
                p["anim_state"] = ""
                _place_random(p)
            continue

        # Сбили машиной?
        for car in cars:
            if car.driven and absf(car.speed_kmh()) > 12.0 and car.global_position.distance_to(pos) < 2.0:
                _knock_down(p, 5.0)
                Sfx.play_at("hit", pos)
                knocked.emit(pos)
                break
        if p["down"]:
            continue

        var corners: Array = p["corners"]
        var goal: Vector3 = corners[int(p["idx"])]
        var to := goal - pos
        to.y = 0.0
        var dir := to.normalized() if to.length() > 0.01 else Vector3.FORWARD
        var fear: float = p.get("fear", 0.0)
        if fear > 0.0:
            p["fear"] = fear - delta
        var stop := false
        if player and player.visible and fear <= 0.0:
            var rel := player.global_position - pos
            stop = rel.dot(dir) > 0.0 and rel.dot(dir) < 1.8 and Vector2(rel.x, rel.z).length() < 1.8
        # машина игрока летит прямо на него — отскакивает в сторону
        if float(p["dodge_t"]) <= 0.0:
            for car in cars:
                if car.driven and absf(car.speed_kmh()) > 18.0:
                    var cv: Vector3 = car.linear_velocity
                    var rel_c: Vector3 = pos - car.global_position
                    rel_c.y = 0.0
                    var along := rel_c.dot(cv.normalized())
                    if along > 0.0 and along < 9.0:
                        var side := Vector3(-cv.z, 0, cv.x).normalized()
                        var off := rel_c.dot(side)
                        if absf(off) < 1.8 and _rng.randf() < 0.75:
                            p["dodge"] = side * (signf(off) if absf(off) > 0.05 else 1.0) * 4.0
                            p["dodge_t"] = 0.55
                            p["fear"] = maxf(fear, 3.0)
        if float(p["dodge_t"]) > 0.0:
            p["dodge_t"] = float(p["dodge_t"]) - delta
            pos += (p["dodge"] as Vector3) * delta
            stop = true
        # иногда останавливается: звонит, смотрит на часы, задумался, оглядывается
        var pause: float = p.get("pause_t", 0.0)
        if pause > 0.0:
            p["pause_t"] = pause - delta
            if fear <= 0.0:
                stop = true
        elif fear <= 0.0 and not stop and String(p.get("pause_anim", "")) == "" and _rng.randf() < delta * 0.012 \
                and pos.distance_to(focus) < 60.0:
            var opts: Array = p.get("acts", [])
            if not opts.is_empty():
                p["pause_anim"] = opts[_rng.randi() % opts.size()]
                p["pause_t"] = _rng.randf_range(4.0, 9.0)
        if pause <= 0.0 and String(p.get("pause_anim", "")) != "":
            p["pause_anim"] = ""

        if not stop:
            var step: float = SPEED * float(p["speed_k"]) * (2.7 if fear > 0.0 else 1.0) * delta
            if to.length() <= step:
                pos = goal
                p["idx"] = (int(p["idx"]) + 1) % 4
            else:
                pos += dir * step
            p["phase"] = float(p["phase"]) + step * 3.2
        p["pos"] = pos
        # своя полоса справа и обход встречных прохожих и стоящих людей (не проходят друг сквозь друга)
        var right := Vector3(-dir.z, 0, dir.x)
        var side: float = p.get("side", 0.55)
        if pos.distance_to(focus) < 70.0:
            var tgt := 0.55
            var vp: Vector3 = pos + right * side
            for o: Dictionary in _peds:
                if o == p or o["down"]:
                    continue
                var rel: Vector3 = (o.get("vpos", o["pos"]) as Vector3) - vp
                rel.y = 0.0
                if rel.length_squared() > 6.0:
                    continue
                var ahead := rel.dot(dir)
                var lat := rel.dot(right)
                if ahead > -0.3 and ahead < 2.0 and absf(lat) < 0.75:
                    tgt -= (signf(lat) if absf(lat) > 0.05 else -1.0) * 0.9
            for ob: Vector3 in _blockers:
                var rel2 := ob - vp
                rel2.y = 0.0
                if rel2.length_squared() > 9.0:
                    continue
                var ahead2 := rel2.dot(dir)
                var lat2 := rel2.dot(right)
                if ahead2 > -0.4 and ahead2 < 2.6 and absf(lat2) < 0.95:
                    tgt -= (signf(lat2) if absf(lat2) > 0.05 else -1.0) * 1.2
            side = move_toward(side, clampf(tgt, -1.5, 1.6), 1.6 * delta)
            p["side"] = side
        p["vpos"] = pos + right * side
        pos = p["vpos"]

        var far := pos.distance_to(focus)
        if far > 260.0:          # игрок ушёл далеко или уехал в другой город — прохожие «переселяются» к нему
            _place_random(p)
            continue
        var near := far < 70.0
        root.visible = near
        var ap = p.get("anim")
        if ap is AnimationPlayer:
            var anim_p := ap as AnimationPlayer
            anim_p.active = near
            if near:
                root.position = pos
                root.rotation.y = atan2(dir.x, dir.z)
                var want := String(p["idle"]) if stop else String(p["walk"])
                if stop and String(p.get("pause_anim", "")) != "" and fear <= 0.0:
                    want = String(p["pause_anim"])
                if fear > 0.0 and not stop and String(p["run"]) != "":
                    want = String(p["run"])
                if want != "" and String(p.get("anim_state", "")) != want and anim_p.has_animation(want):
                    anim_p.play(want, 0.25)
                    p["anim_state"] = want
                anim_p.speed_scale = 1.0 if stop else (SPEED * float(p["speed_k"]) * 2.7 / 4.0 if fear > 0.0 else SPEED * float(p["speed_k"]) / 1.5)
            continue
        if near:
            root.position = pos
            root.rotation.y = atan2(dir.x, dir.z)
            var swing := sin(float(p["phase"])) * (0.0 if stop else 0.55)
            var legs: Array = p["legs"]
            (legs[0] as Node3D).rotation.x = swing
            (legs[1] as Node3D).rotation.x = -swing


## Ставит пешехода на тротуар случайного квартала, подальше от камеры, если можно.
func _place_random(p: Dictionary) -> void:
    # в том городе, где сейчас игрок: Казань или Пятигорск (за рекой)
    var in_py := focus.x < CityBuilder.RIVER_X0
    var g := CityBuilder.PY_GRID if in_py else CityBuilder.GRID
    var org := CityBuilder.PY_ORG if in_py else Vector3.ZERO
    # квартал рядом с игроком (±2 квартала) — людно там, где он ходит
    var fi := clampi(roundi((focus.x - org.x) / CityBuilder.PITCH), -g, g)
    var fj := clampi(roundi((focus.z - org.z) / CityBuilder.PITCH), -g, g)
    var c := org + Vector3(clampi(fi + _rng.randi_range(-2, 2), -g, g) * CityBuilder.PITCH, 0.0,
            clampi(fj + _rng.randi_range(-2, 2), -g, g) * CityBuilder.PITCH)
    var y := CityBuilder.SIDE_H
    var corners := [c + Vector3(-WALK, y, -WALK), c + Vector3(WALK, y, -WALK),
            c + Vector3(WALK, y, WALK), c + Vector3(-WALK, y, WALK)]
    if _rng.randf() < 0.5:
        corners.reverse()
    var idx := _rng.randi() % 4
    var prev: Vector3 = corners[(idx + 3) % 4]
    var nxt: Vector3 = corners[idx]
    p["corners"] = corners
    p["idx"] = idx
    p["pos"] = prev.lerp(nxt, _rng.randf())
    p["speed_k"] = _rng.randf_range(0.8, 1.2)


func _make_ped() -> Dictionary:
    if not _scenes.is_empty():
        var d3 := _make_ped_3d()
        if not d3.is_empty():
            return d3
    var si := _rng.randi() % SHIRTS.size()
    var pi_ := _rng.randi() % PANTS.size()
    var bk := si * 10 + pi_
    if not _body_meshes.has(bk):
        _body_meshes[bk] = _build_body_mesh(SHIRTS[si], si, pi_)
    if not _leg_meshes.has(pi_):
        _leg_meshes[pi_] = _build_leg_mesh(PANTS[pi_], pi_)

    var root := Node3D.new()
    add_child(root)
    var body := MeshInstance3D.new()
    body.mesh = _body_meshes[bk]
    root.add_child(body)
    var legs := []
    for side: float in [-0.1, 0.1]:
        var hip := Node3D.new()
        hip.position = Vector3(side, 0.92, 0)
        root.add_child(hip)
        var leg := MeshInstance3D.new()
        leg.mesh = _leg_meshes[pi_]
        hip.add_child(leg)
        legs.append(hip)
    return {"root": root, "legs": legs, "pos": Vector3.ZERO, "corners": [], "idx": 0,
            "phase": _rng.randf() * TAU, "speed_k": 1.0, "down": false, "timer": 0.0, "fear": 0.0, "dodge": Vector3.ZERO,
            "dodge_t": 0.0, "acts": []}


## Туловище, руки и голова — один меш (рубашка, брюки, кожа, волосы).
## Детали смотрят в -Z, а прохожий идёт в +Z — поэтому всё повёрнуто на 180°.
func _build_body_mesh(shirt: Color, si := 0, pi_ := 0) -> ArrayMesh:
    var flip := Transform3D(Basis(Vector3.UP, PI), Vector3.ZERO)
    var shirt_mat := _cloth_mat(shirt, ["cloth_sweater", "cloth_leather2", "cloth_knit", "cloth_nylon"][si % 4])
    var pants_mat := _cloth_mat(PANTS[pi_], "cloth_jeans" if pi_ % 2 == 0 else "cloth_denim")
    var hair_mat := StandardMaterial3D.new()
    hair_mat.albedo_color = [Color(0.12, 0.08, 0.05), Color(0.35, 0.25, 0.15), Color(0.6, 0.5, 0.3), Color(0.2, 0.2, 0.2)][si % 4]
    var st_shirt := SurfaceTool.new()
    st_shirt.begin(Mesh.PRIMITIVE_TRIANGLES)
    st_shirt.set_material(shirt_mat)
    st_shirt.append_from(BodyMesh.part("torso"), 0, flip * Transform3D(Basis(), Vector3(0, 1.0, 0)))
    for side: float in [-1.0, 1.0]:
        var sh := Vector3(0.26 * side, 1.45, 0)
        var tilt := Basis(Vector3.BACK, 0.08 * side)
        st_shirt.append_from(_sphere(0.085), 0, flip * Transform3D(Basis(), sh))
        st_shirt.append_from(BodyMesh.part("upper_arm"), 0, flip * Transform3D(tilt, sh))
        var el := sh + tilt * Vector3(0, -0.29, 0)
        st_shirt.append_from(BodyMesh.part("forearm"), 0, flip * Transform3D(tilt, el))
    var st_pants := SurfaceTool.new()
    st_pants.begin(Mesh.PRIMITIVE_TRIANGLES)
    st_pants.set_material(pants_mat)
    st_pants.append_from(BodyMesh.part("pelvis"), 0, flip * Transform3D(Basis(), Vector3(0, 0.97, 0)))
    var st_skin := SurfaceTool.new()
    st_skin.begin(Mesh.PRIMITIVE_TRIANGLES)
    st_skin.set_material(_skin)
    st_skin.append_from(_sphere(0.12), 0, flip * Transform3D(Basis(), Vector3(0, 1.68, 0)))
    var neck := CylinderMesh.new()
    neck.top_radius = 0.055
    neck.bottom_radius = 0.06
    neck.height = 0.12
    neck.radial_segments = 10
    st_skin.append_from(neck, 0, flip * Transform3D(Basis(), Vector3(0, 1.58, 0)))
    for side: float in [-1.0, 1.0]:
        var tilt := Basis(Vector3.BACK, 0.08 * side)
        var el := Vector3(0.26 * side, 1.45, 0) + tilt * Vector3(0, -0.29, 0)
        st_skin.append_from(BodyMesh.part("hand"), 0, flip * Transform3D(tilt, el))
    var st_hair := SurfaceTool.new()
    st_hair.begin(Mesh.PRIMITIVE_TRIANGLES)
    st_hair.set_material(hair_mat)
    st_hair.append_from(BodyMesh.part("hair"), 0, flip * Transform3D(Basis(), Vector3(0, 1.705, 0.02)))
    var mesh := ArrayMesh.new()
    st_shirt.commit(mesh)
    st_pants.commit(mesh)
    st_skin.commit(mesh)
    st_hair.commit(mesh)
    return mesh


## Нога от бедра вниз: бедро, колено, голень, ботинок.
func _build_leg_mesh(col: Color, pi_ := 0) -> ArrayMesh:
    var flip := Transform3D(Basis(Vector3.UP, PI), Vector3.ZERO)
    var mat := _cloth_mat(col, "cloth_jeans" if pi_ % 2 == 0 else "cloth_denim")
    var shoe := StandardMaterial3D.new()
    shoe.albedo_color = Color(0.12, 0.11, 0.1)
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    st.set_material(mat)
    st.append_from(BodyMesh.part("thigh"), 0, flip)
    st.append_from(_sphere(0.068), 0, flip * Transform3D(Basis(), Vector3(0, -0.45, 0)))
    st.append_from(BodyMesh.part("calf"), 0, flip * Transform3D(Basis(), Vector3(0, -0.45, 0)))
    var st2 := SurfaceTool.new()
    st2.begin(Mesh.PRIMITIVE_TRIANGLES)
    st2.set_material(shoe)
    st2.append_from(BodyMesh.part("shoe"), 0, flip * Transform3D(Basis(Vector3.RIGHT, -PI * 0.5), Vector3(0, -0.86, 0.07)))
    var mesh := ArrayMesh.new()
    st.commit(mesh)
    st2.commit(mesh)
    return mesh


func _cloth_mat(col: Color, tex_name: String) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = col
    m.roughness = 0.85
    var path := "res://textures/%s.png" % tex_name
    if ResourceLoader.exists(path):
        m.albedo_texture = load(path)
        m.uv1_triplanar = true
        m.uv1_scale = Vector3.ONE * 3.5
    return m


func _sphere(r: float) -> SphereMesh:
    var m := SphereMesh.new()
    m.radius = r
    m.height = r * 2.0
    m.radial_segments = 12
    m.rings = 6
    return m


func _capsule(r: float, h: float) -> CapsuleMesh:
    var m := CapsuleMesh.new()
    m.radius = r
    m.height = h
    m.radial_segments = 10
    m.rings = 4
    return m



# ---------------------------------------------------------------- 3D-прохожие

func _ctex(tex_name: String) -> Texture2D:
    if _tex.has(tex_name):
        return _tex[tex_name]
    var path := tex_name if tex_name.begins_with("res://") else "res://textures/%s.png" % tex_name
    var t: Texture2D = load(path) if ResourceLoader.exists(path) else null
    _tex[tex_name] = t
    return t


func _make_ped_3d() -> Dictionary:
    var female := _scenes.has("female") and (_rng.randf() < 0.45 or not _scenes.has("male"))
    var sc: PackedScene = _scenes["female" if female else "male"]
    var model := sc.instantiate() as Node3D
    if model == null:
        return {}
    var root := Node3D.new()
    add_child(root)
    root.add_child(model)
    var players := model.find_children("*", "AnimationPlayer", true, false)
    var ap: AnimationPlayer = players[0] if not players.is_empty() else null
    # Godot при импорте убирает «_Loop» из имён: Walk_Loop -> Walk. Ищем по началу имени.
    var walk_a := _find_anim(ap, "walk")
    var idle_a := _find_anim(ap, "idle")
    var die_a := _find_anim(ap, "death")
    if ap:
        for an: String in [walk_a, idle_a]:
            if an != "":
                ap.get_animation(an).loop_mode = Animation.LOOP_LINEAR
        # спина ровнее (как у игрока): у женской модели свои анимации — правим один раз
        var sks := model.find_children("*", "Skeleton3D", true, false)
        if walk_a != "" and not sks.is_empty() and (sks[0] as Skeleton3D).find_bone("spine_01") >= 0:
            Poses.fix_lean(ap, sks[0] as Skeleton3D, walk_a, 0.35)
            Poses.install(ap, sks[0] as Skeleton3D)   # жесты для остановок (одна библиотека на модель — быстро)
        if walk_a != "":
            ap.play(walk_a)
            ap.seek(_rng.randf() * 1.0, true)

    # одежда
    var tops: Array = FEMALE_TOPS if female else MALE_TOPS
    var top: Array = tops[_rng.randi() % tops.size()]
    var style := String(top[1])
    var pants_l: Array = FEMALE_PANTS if female else MALE_PANTS
    var shoes_l: Array = FEMALE_SHOES if female else MALE_SHOES
    var pants_name: String = top[0] if style.contains("dress") else pants_l[_rng.randi() % pants_l.size()]
    var shoes_name: String = shoes_l[_rng.randi() % shoes_l.size()]
    var mat := ShaderMaterial.new()
    mat.shader = _shader
    if female:
        preload("res://scripts/outfits.gd").setup_female(mat, HAIR_COLORS[_rng.randi() % HAIR_COLORS.size()])
    else:
        preload("res://scripts/outfits.gd").setup_male(mat, HAIR_COLORS[_rng.randi() % HAIR_COLORS.size()])
    mat.set_shader_parameter("jacket_tex", _ctex(String(top[0])))
    mat.set_shader_parameter("pants_tex", _ctex(pants_name))
    mat.set_shader_parameter("shoes_tex", _ctex(shoes_name))
    var tint := _rng.randf_range(0.85, 1.05)
    for slot: String in ["jacket", "pants", "shoes"]:
        mat.set_shader_parameter(slot + "_col", Vector3(tint, tint, tint))
    mat.set_shader_parameter("long_sleeves", 0.0 if style.contains("short") else 1.0)
    mat.set_shader_parameter("print_on", 0.0)
    mat.set_shader_parameter("skin_tint", SKIN_TINTS[_rng.randi() % SKIN_TINTS.size()])
    preload("res://scripts/outfits.gd").apply(mat, String(top[0]), pants_name, shoes_name, Color.WHITE, female)
    # телосложение: прохожие разного роста и комплекции
    var bl: Array = BUILDS[_rng.randi() % BUILDS.size()]
    preload("res://scripts/outfits.gd").apply_build(model, [bl[0] * _rng.randf_range(0.97, 1.03), bl[1], bl[2], bl[3]], model.scale.x,
            String(top[0]), pants_name, female)

    # причёска и цвет волос
    var hair_mat := StandardMaterial3D.new()
    var hc: Color = HAIR_COLORS[_rng.randi() % HAIR_COLORS.size()]
    hair_mat.albedo_color = hc.lightened(0.15)
    var ht := _ctex(CHAR_DIR + ("hair2_gray.png" if female else "hair_gray.png"))
    if ht:
        hair_mat.albedo_texture = ht
    hair_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
    hair_mat.alpha_scissor_threshold = 0.4
    hair_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    hair_mat.roughness = 0.7
    var alt := _rng.randf() < 0.4
    var beard := not female and _rng.randf() < 0.3
    for mi: Node in model.find_children("*", "MeshInstance3D", true, false):
        var mesh_i := mi as MeshInstance3D
        mesh_i.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        var nm := String(mesh_i.name).to_lower()
        if nm.contains("hairalt"):
            mesh_i.visible = (nm.contains("beard") and beard) or (not nm.contains("beard") and alt)
            mesh_i.material_override = hair_mat
        elif nm.contains("hair"):
            mesh_i.visible = not alt
            mesh_i.material_override = hair_mat
        elif nm.contains("eyebrow"):
            mesh_i.material_override = hair_mat
        elif nm.contains("superhero") or nm.contains("body"):
            mesh_i.material_override = mat
    # рост у всех чуть разный
    model.scale *= _rng.randf_range(0.94, 1.05)
    # головные уборы: в холода (октябрь–апрель) у многих шапки — «петушок», ондатра, кепка
    var month := int(Time.get_date_dict_from_system()["month"])
    var cold := month >= 10 or month <= 4
    var hat_kind := ""
    if cold and _rng.randf() < (0.55 if count >= COUNT else 0.3):   # на слабом устройстве шапок меньше
        hat_kind = ["petushok", "petushok", "ondatra", "kepka"][_rng.randi() % 4] if not female else ["petushok", "ondatra"][_rng.randi() % 2]
    elif not female and _rng.randf() < 0.15:
        hat_kind = "kepka"
    if hat_kind != "":
        var sks2 := model.find_children("*", "Skeleton3D", true, false)
        if not sks2.is_empty() and (sks2[0] as Skeleton3D).find_bone("Head") >= 0:
            var att := BoneAttachment3D.new()
            att.bone_name = "Head"
            sks2[0].add_child(att)
            var cols := [Color(0.62, 0.12, 0.1), Color(0.15, 0.25, 0.5), Color(0.2, 0.2, 0.22), Color(0.85, 0.82, 0.75), Color(0.25, 0.4, 0.25)]
            var h := Hats.build(hat_kind, cols[_rng.randi() % cols.size()])
            preload("res://scripts/outfits.gd").place_hat(h, female)
            att.add_child(h)
            if Hats.covers_hair(hat_kind):
                for mi2: Node in model.find_children("*", "MeshInstance3D", true, false):
                    var n2 := String(mi2.name).to_lower()
                    if n2.contains("hair") and not n2.contains("beard"):
                        (mi2 as MeshInstance3D).visible = false
    return {"root": root, "legs": [], "pos": Vector3.ZERO, "corners": [], "idx": 0, "anim": ap, "anim_state": walk_a,
            "walk": walk_a, "idle": idle_a, "die": die_a,
            "run": "Anim_Jog" if ap and ap.has_animation("Anim_Jog") else _find_anim(ap, "jog"),
            "phase": _rng.randf() * TAU, "speed_k": 1.0, "down": false, "timer": 0.0, "fear": 0.0, "dodge": Vector3.ZERO,
            "dodge_t": 0.0, "acts": _acts(ap)}


## Что прохожий может делать, остановившись (только то, что есть в его анимациях).
func _acts(ap: AnimationPlayer) -> Array:
    var out := []
    if ap == null:
        return out
    for an: String in ["Pose_Phone", "Anim_Watch", "Pose_Think", "Pose_Arms", "Anim_Look", "Anim_Shrug"]:
        if ap.has_animation(an):
            out.append(an)
    return out


## Испуг: стрельба или драка рядом — прохожие в радиусе убегают от этого места.
func scare(from: Vector3, radius: float) -> void:
    for p: Dictionary in _peds:
        if p["down"]:
            continue
        var pos: Vector3 = p.get("vpos", p["pos"])
        if pos.distance_to(from) > radius:
            continue
        var was: float = p.get("fear", 0.0)
        p["fear"] = _rng.randf_range(5.0, 9.0)
        if was > 0.0:
            continue
        # бежать по тротуару от опасности: если путь ведёт к ней — развернуться
        var corners: Array = p["corners"]
        var goal: Vector3 = corners[int(p["idx"])]
        if (goal - pos).dot(from - pos) > 0.0:
            corners.reverse()
            p["idx"] = (3 - int(p["idx"]) + 1) % 4


## Анимация, имя которой начинается с base (без учёта регистра); точное совпадение — в приоритете.
func _find_anim(ap: AnimationPlayer, base: String) -> String:
    if ap == null:
        return ""
    var best := ""
    for an in ap.get_animation_list():
        var low := String(an).to_lower()
        if low == base or low == base + "_loop" or low == base + "01":
            return String(an)
        if best == "" and low.begins_with(base):
            best = String(an)
    return best



## Уронить прохожего (сбили, ударили, подстрелили).
func _knock_down(p: Dictionary, seconds: float) -> void:
    var root: Node3D = p["root"]
    var pos: Vector3 = p["pos"]
    p["down"] = true
    p["timer"] = seconds
    var ap_d = p.get("anim")
    var die_name := String(p.get("die", ""))
    if ap_d is AnimationPlayer and die_name != "":
        (ap_d as AnimationPlayer).active = true
        (ap_d as AnimationPlayer).play(die_name, 0.1)
    else:
        root.rotation.x = -PI * 0.5
        root.position = pos + Vector3(0, 0.25, 0)


## Удар или выстрел: ближайший прохожий в конусе перед стреляющим падает.
## Возвращает точку попадания или Vector3.INF, если никого не задело.
func hit(origin: Vector3, dir: Vector3, max_range: float, cone_deg: float) -> Vector3:
    var best: Dictionary = {}
    var best_d := max_range
    var cone_cos := cos(deg_to_rad(cone_deg))
    for p: Dictionary in _peds:
        if p["down"]:
            continue
        var pos: Vector3 = p.get("vpos", p["pos"])
        var to := pos + Vector3(0, 1.1, 0) - origin
        var d := to.length()
        if d > best_d or d < 0.05:
            continue
        var flat := Vector3(to.x, 0, to.z).normalized()
        if flat.dot(Vector3(dir.x, 0, dir.z).normalized()) < cone_cos:
            continue
        best = p
        best_d = d
    if best.is_empty():
        return Vector3.INF
    _knock_down(best, 8.0)
    var hp: Vector3 = best.get("vpos", best["pos"])
    return hp + Vector3(0, 1.1, 0)
